#include "CuaIOParInt.hh"

int main () {
    queue<ParInt> original, c1,c2;
    int t1 = 0, t2 = 0;
    
    llegirCuaParInt(original);
    
    while(not original.empty()){
        ParInt p = original.front();
        if(t1 <= t2){
            t1 += p.segon();
            c1.push(p);
        }
        
        else {
            t2 += p.segon();
            c2.push(p);
        }
        original.pop();
    }
    
    escriureCuaParInt(c1);
    cout << endl;
    escriureCuaParInt(c2);
}

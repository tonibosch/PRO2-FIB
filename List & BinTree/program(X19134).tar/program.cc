#include "LlistaIOParInt.hh"

int main () {
    list<ParInt> l;
    LlegirLlistaParInt(l);
    
    int N,apar = 0,suma = 0;
    cin >> N;
    
    list<ParInt>::const_iterator it = l.begin();
    while(it != l.end()){
        if((*it).primer() == N) {
            ++apar;
            suma += (*it).segon();
        }
        ++it;    
    }
    cout << N << " " << apar << " " << suma << endl;
}

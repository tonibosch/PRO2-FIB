#include "LlistaIOEstudiant.hh"

void LlegirLlistaEstudiant(list<Estudiant>& l){
    int nota, dni;
    while (cin >> dni >> nota and dni != 0 and nota != 0){
        l.insert(l.end(),dni);
    }
}

void EscriureLlistaEstudiant(list<Estudiant>& l) {
    list<Estudiant>::const_iterator it = l.begin();
    while(it != l.end()){
        (*it).escriure();
        ++it;
    }
}

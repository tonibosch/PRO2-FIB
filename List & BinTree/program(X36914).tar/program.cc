#include "LlistaIOEstudiant.hh"

int main (){
    list<Estudiant> l;
    LlegirLlistaEstudiant(l);
    
    int n,apar = 0;
    cin >> n;
    
    list<Estudiant>::const_iterator it = l.begin();
    while(it != l.end()){
        if((*it).consultar_DNI() == n) ++apar;
        ++it;
    }
    cout << n << " " << apar << endl;
}

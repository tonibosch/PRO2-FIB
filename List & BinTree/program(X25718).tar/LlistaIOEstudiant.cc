#include "LlistaIOEstudiant.hh"

// Pre: l és buida; el canal estandar d’entrada conté parelles
// de valors <enter, double>, acabat per un parell 0 x (qualsevol double)
// Post: s’han afegit al final de l els estudiants llegits fins al 0 x (no inclòs)

void LlegirLlistaEstudiant(list<Estudiant>& l) {
    Estudiant e;
    bool final = false;
    while(not final){
        e.llegir();
        if(0 == e.consultar_DNI()) final = true;
        else l.insert(l.end(),e);
    }
}


// Pre: cert
// Post: s’han escrit al canal estandar de sortida els elements de l
void EscriureLlistaEstudiant(const list<Estudiant>& l) {
    list<Estudiant>::const_iterator it = l.begin();
    
    while (it != l.end()){
        (*it).escriure();
        ++it;
    }
}

/*
int dni;
    double nota;
    while (cin >> dni and dni != 0){
        cin >> nota;
        Estudiant e(dni);
        if(0 <= nota and nota <= e.nota_maxima()) e.afegir_nota(nota);
        l.insert(l.end(),e);
    }
    cin >> nota;
*/
